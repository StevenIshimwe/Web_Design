<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Message Display</title>
</head>
<body>
    <table>
    <tr>
     <th>NAME</th>
     <th>PHONENUMBER</th>
     <th>EMAIL</th>
     <th>ADDRESS</th>
     <th>MESSAGE</th>
    </tr>

        <?php
$connect = mysqli_connect('localhost','root','','emergingtech');

$sel=mysqli_query($connect,"select* from contact");

while($row = mysqli_fetch_array($sel)){





?>
<tr>
<td><?php echo $row['name']?></td>
<td><?php echo $row['phonenumber']?></td>
<td><?php echo $row['email']?></td>
<td><?php echo $row['address']?></td>
<td><?php echo $row['message']?></td>
<td><a href="delete.php?delete=<?php echo $row['email'];?>">Delete</a></td>
<td><a href="delete.php?delete=<?php echo $row['email'];?>">Reply</a></td>
</tr>

<?php }?>
    </table>
</body>
</html>