<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        *{
           margin: 0;
           padding: 0;
           font-size: large;
       }

       .header{
           position: fixed;
           top: 0;
           left: 0;
           width: 100%;
           background-color: #333;
           color: white;
           text-align: center;
           font-size: 16px;
       }

       .navbar{
           display: flex;
           flex-direction: row;
           justify-content: space-around;
           align-content: center;
           align-items: center;
           height: 50px;
           background-color: #3c3e3f;
           padding: 5px;
       }

       a{
           text-decoration: none;
           padding: 15px;
           color: white;
       }

       .hover>a:hover{
           color: black;
           background-color: aquamarine; 
           border-radius: 30px;
           transition: width 2s;
       }

       .container{
           width: 100%;
           height: 100vh;
           justify-content: center;
           align-content: center;
           align-items: center;
           text-align: center;
           background-image: url(./img-electronicdevices/Elevate\ Your\ iPad\ Pro.jpg);
       }
       .footer{
            background-color: #3c3e3f;
            display: flex;
            flex-direction: column;
            align-items: center;
            color: white; 
            padding: 20px;
        }
       
        .footer-contact {
            display: flex;
            align-items:end;
            flex-direction: column;

        
        }

       .footer-top {
            width: 100%;
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .footer-middle {
            width: 100%;
            text-align: center;
            margin-bottom: 10px;
        }

        .footer-about, .footer-contact {
            width: 40%;
        }

       .about{
        justify-content: center;
        justify-items: center;
        text-align: center;
        display: flex;
        flex-direction: column;
        gap: 15px;
       }

       input[type=submit]{
        background-color: rgb(179, 79, 79);
        border-radius: 5px;
        padding: 10px;
        margin: 5px;
       }

        
        .social-icons {
            margin-top: 20px;
        }

        .social-icons a {
            display: inline-block;
            margin: 0 10px;
            color: rgb(228, 219, 231);
            font-size: 1.5rem;
        }

        .social-icons a:hover {
            color: #3b5998; 
        }
        
        .footer a {
            margin-left: 10px;
        }

        .footer-subscribe .form-control {
            border-color: #fff !important;
        }

        .footer-subscribe .form-control::placeholder {
            color: rgba(255, 255, 255, 0.5);
            font-weight: 200;
            font-style: italic;
        }

        .footer-subscribe .btn {
            height: 43px;
            line-height: 1;
            border: 1px solid #fff;
            background: #fff !important;
            color: #000 !important;
        }

        .footer-subscribe .btn:hover, .footer-subscribe .btn:focus, .footer-subscribe .btn:active {
            border: 1px solid #fff;
        }
   </style>
</head>
<body>
    <header class="header">
        <div class="navbar">
            <div>
                <h2><img src="download.jpg" width="100" height="50" ></h2>
            </div>
            <div class="nav-links hover">
                <a href="./home.php">Home</a>
                <a href="./car.php">Cars</a>
                <a href="./house.php">Houses</a>
                <a href="./about.php">About Us</a>
                <a href="./services.php">Services</a>
                <a href="./contact.php">Contact Us</a>
            </div>
            </div>
        </div>
    </header><br><br><br><br>
    <main>
      <div class="about">
        <div>
            <h2>ABOUT US</h2>&nbsp;<br>
            <img src="121.jpg" alt="" width="260px" height="260px" style="border-radius: 50%;">
            <p>SALES MANAGER</p>
        </div><br>
       
            <ul>
              <h2><u>OUR VISION</h2></u>
                <li>Being a leading global company for customer need &satisfaction.</li>
                <li>Being social/community responsible.</li>
            </ul>
            <ul>
                <h2><u>OUR MISSION</h2></u>
                <li>Provide high quality products and service.</li>
                <li>Create and cultivate long terms relationship with clients and stakeholders.</li>
                <li>Respond immediately to the changing needs of our clients.</li>
                <li>Achieve complete customer satisfaction.</li>
                <li>Improve our service continuously.</li>
            </ul>

            <ul>
                <h2><u>OUR VALUE</h2></u>
                <ul>
                <li>Integrity</li>
                <li>Continuous improvement</li>
                <li>Excellent Service</li>
                <li>Time Management</li>
                <li>Accountability</li><br>
        </div>
        
    </div><br><br><br><br> 
    </main>
    <footer>
        <div class="footer">
            <div class="footer-top">
                <div class="footer-about">
                    <h2 class="footer-heading mb-4">About Us</h2>
                    <p> OUR MISSION<br>
                        - Provide high quality products and service.<br>
                        - Respond immediately to the changing needs of our clients.<br>
                         -Achieve complete customer satisfaction.<br>
                        - Improve our service continuously.</p>
                </div>
                <div class="footer-contact">
                    <h3>Contact us on Social media.</h3>
                    <div class="social-icons">
                       
                        <a href="https://www.facebook.com/sciandagroup" target="_blank"><i class="fab fa-facebook-square"></i></a>
                        <a href="https://www.instagram.com/sciandagroup" target="_blank"><i class="fab fa-instagram-square"></i></a>
                        <a href="https://www.youtube.com/@SCRWANDA" target="_blank"><i class="fab fa-youtube-square"></i></a>
                        <a href="https://www.twitter.com/sciandagroup" target="_blank"><i class="fab fa-twitter-square"></i></a>
                    </div>
                </div>
            </div>
            
            <p>&copy; All right Reserved by SCIANDA GROUP LTD.</p>
        </div>
    </footer>

</body>
</html>
