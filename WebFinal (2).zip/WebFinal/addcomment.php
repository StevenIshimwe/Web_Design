<?php

$conn= mysqli_connect('localhost','root','','emergingtech');

if(isset($_POST['submit'])){

    $fullname= $_POST['name'];
    $phonenumber= $_POST['phoneNumber'];
    $Email= $_POST['email'];
    $Address= $_POST['address'];
    $Message= $_POST['message'];
    $query = mysqli_query($conn,"insert into Contact values('$fullname','$phonenumber','$Email','$Address','$Message')");
    
    if($query){
        echo "<script>alert('Message sent successfully!')</script>";
       
    }else
    echo "<script>alert('Message Failed failed to be sent, try again!')</script>";
        include "displayMessage.php"; 

}
?>