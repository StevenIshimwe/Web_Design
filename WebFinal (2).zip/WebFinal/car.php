<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            font-size: large;
        }

        .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background-color: #333;
            color: white;
            text-align: center;
            font-size: 16px;
        }

        .navbar {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-content: center;
            align-items: center;
            height: 50px;
            background-color: #3c3e3f;
            padding: 5px;
        }

        .navbar h2 {
            margin-left: 10px;
        }

        .nav-links {
            display: flex;
            align-items: center;
        }

        .nav-links a {
            text-decoration: none;
            padding: 15px;
            color: white;
        }

        .hover > a:hover {
            color: black;
            background-color: aquamarine; 
            border-radius: 30px;
            transition: width 2s;
        }

        .breadcrumb {
            margin-top: 60px;
            padding: 10px 20px;
            background-color: orange;
            font-size: 14px;
            color: white;
        }

        .breadcrumb a {
            color: white;
            text-decoration: none;
        }

        .breadcrumb a:hover {
            text-decoration: underline;
        }

        .container {
            display: flex;
            flex-direction: row;
            justify-content: space-around;
            text-align: center;
            border-radius: 5px;
            gap: 25px;
        }

        .footer {
            background-color: #3c3e3f;
            display: flex;
            flex-direction: column;
            align-items: center;
            color: white; 
            padding: 20px;
        }

        .footer-top {
            width: 100%;
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .footer-middle {
            width: 100%;
            text-align: center;
            margin-bottom: 10px;
        }

        .footer-about, .footer-contact {
            width: 40%;
        }

        
        .social-icons {
            margin-top: 20px;
        }

        .social-icons a {
            display: inline-block;
            margin: 0 10px;
            color: white;
            font-size: 1.5rem;
        }

        .social-icons a:hover {
            color: #3b5998; 
        }

        .footer a {
            margin-left: 10px;
        }

        .footer-subscribe .form-control {
            border-color: #fff !important;
        }

        .footer-subscribe .form-control::placeholder {
            color: rgba(255, 255, 255, 0.5);
            font-weight: 200;
            font-style: italic;
        }

        .footer-subscribe .btn {
            height: 43px;
            line-height: 1;
            border: 1px solid #fff;
            background: #fff !important;
            color: #000 !important;
        }

        .footer-subscribe .btn:hover, .footer-subscribe .btn:focus, .footer-subscribe .btn:active {
            border: 1px solid #fff;
        }

        .additional-section {
            background-color: white;
            text-align: center;
            padding: 40px;
            margin-top: 20px;
        }

        
        .additional-section h1 {
            font-size: 2.5rem; 
            color: #333; 
        }
        
        .Gallery{
            display: flex;
            flex-direction: column;
            background-color: rgba(0, 0, 0, 0.9);
            color: white;
            align-items: center;
            padding: 20px;
        }
        .gallery{
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            box-sizing: border-box;
        }
        .gallery-item {
            text-align: center;
            margin: 10px;
        }
        .gallery-item img{
            width: 360px;
            height: 240px;
        }
        .gallery-item .caption {
            margin-top: 10px;
            font-size: 14px;
            color: white;
        }
        .footer-contact {
            display: flex;
            align-items:end;
            flex-direction: column;

        
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="navbar">
            <div>
                <h2><img src="download.jpg" width="100" height="50" ></h2>
            </div>
            <div class="nav-links hover">
                <a href="./home.php">Home</a>
                <a href="./car.php">Cars</a>
                <a href="./house.php">Houses</a>
                <a href="./about.php">About Us</a>
                <a href="./services.php">Services</a>
                <a href="./contact.php">Contact Us</a>
            </div>
        </div>
    </header>
    <br><br><br><br><br>
<section id="Gallery" class="Gallery">
   <h1 class="headings">Gallery</h1>
   <div class="gallery">
       <div class="gallery-item">
           <img src="1.jpg" alt="sciandagroup ">
           <div class="caption">60,000,000 frw</div>
       </div>
       <div class="gallery-item">
           <img src="2.jpg" alt=" ">
           <div class="caption">25,000,000 frw</div>
       </div>
       <div class="gallery-item">
           <img src="3.jpg" alt=" ">
           <div class="caption">65,000,000 frw</div>
       </div>
       <div class="gallery-item">
           <img src="4.jpg" alt=" ">
           <div class="caption">70,000,000 frw</div>
       </div>
       <div class="gallery-item">
           <img src="5.jpg" alt=" ">
           <div class="caption">62,000,000 frw</div>
       </div>
       <div class="gallery-item">
           <img src="6.jpg" alt=" ">
           <div class="caption">65,000,000 frw</div>
       </div>
   </div>
</section>
<footer>
    <div class="footer">
        <div class="footer-top">
            <div class="footer-about">
                <h2 class="footer-heading mb-4">About Us</h2>
                <p> OUR MISSION<br>
                    - Provide high quality products and service.<br>
                    - Respond immediately to the changing needs of our clients.<br>
                     -Achieve complete customer satisfaction.<br>
                    - Improve our service continuously.</p>
            </div>
            <div class="footer-contact">
                <h3>Contact us on Social media.</h3>
                <div class="social-icons">
                   
                    <a href="https://www.facebook.com/sciandagroup" target="_blank"><i class="fab fa-facebook-square"></i></a>
                    <a href="https://www.instagram.com/sciandagroup" target="_blank"><i class="fab fa-instagram-square"></i></a>
                    <a href="https://www.youtube.com/@SCRWANDA" target="_blank"><i class="fab fa-youtube-square"></i></a>
                    <a href="https://www.twitter.com/sciandagroup" target="_blank"><i class="fab fa-twitter-square"></i></a>
                </div>
            </div>
        </div>
        
        <p>&copy; All right Reserved by SCIANDA GROUP LTD.</p>
    </div>
</footer>
</body>
</html>
