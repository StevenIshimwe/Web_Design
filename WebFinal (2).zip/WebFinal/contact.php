<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        * {
            font-size: large;
            padding: 0;
            margin: 0;
        }
        div {
            border-radius: 5px;
            padding: 20px;
            color: white;
        }
        input[type=text], select, textarea {
            display: block;
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
            width: 100%; 
            color: white;
            background-color: #3c3e3f; 
        }

        input[type=submit] {
            width: 100%; 
            padding: 10px; 
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
            color: white;
            background-color: rgb(187, 143, 91);
            font-size: 0.8rem; 
            cursor: pointer; 
        }

        input[type=submit]:hover {
            background-color: #3c3e3f; 
        }

        .footer {
            background-color: #3c3e3f;
            display: flex;
            flex-direction: column;
            align-items: center;
            color: white; 
            padding: 20px;
        }

        .footer-top {
            width: 100%;
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .footer-middle {
            width: 100%;
            text-align: center;
            margin-bottom: 10px;
        }

        .footer-about, .footer-contact {
            width: 40%;
        }

        
        .social-icons {
            margin-top: 20px;
        }

        .social-icons a {
            display: inline-block;
            margin: 0 4px;
            color: white;
            font-size: 1rem;
        }

        .social-icons a:hover {
            color: #3b5998; 
        }

        .footer a {
            margin-left: 10px;
        }

        .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background-color: #333;
            color: white;
            text-align: center;
            font-size: 16px;
        }

        .navbar {
            display: flex;
            flex-direction: row;
            justify-content: space-around;
            align-content: center;
            align-items: center;
            height: 50px;
            background-color: #3c3e3f;
            padding: 5px;
        }

        a {
            text-decoration: none;
            padding: 15px;
            color: white;
        }

        .hover > a:hover {
            color: black;
            background-color: aquamarine;
            border-radius: 30px;
            transition: width 2s;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh; 
            background-color: rgb(247, 244, 242);
            padding-top: 60px; 
        }

        .form-container {
            background-color: #3c3e3f;
            padding: 20px;
            border-radius: 10px;
            width: 50%; 
            max-width: 600px; 
            color: white;
        }

        .form-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .footer-contact {
            display: flex;
            align-items:end;
            flex-direction: column;

        
        }
    </style>
</head>
<body>
<header class="header">
    <div class="navbar">
        <div>
            <h2><img src="download.jpg" width="100" height="50" ></h2>
        </div>
        <div class="nav-links hover">
                <a href="./home.php">Home</a>
                <a href="./car.php">Cars</a>
                <a href="./house.php">Houses</a>
                <a href="./about.php">About Us</a>
                <a href="./services.php">Services</a>
                <a href="./contact.php">Contact Us</a>
            </div>
    </div>
</header>
<main>
    <div class="container">
        <div class="form-container">
            <h2>At SCIANDA GROUP LTD, The customer is the King, Get in touch with us, We will love to hear from you.</h2>
            <form action="addcomment.php" method="POST">
                <label for="name">Name</label>
                <input type="text" id="name" name="name" placeholder="Your full name..." required>

                <label for="phoneNumber">PhoneNumber</label>
                <input type="text" id="phoneNumber" name="phoneNumber" placeholder="Your phoneNumber..."required>

                <label for="email">Email</label>
                <input type="text" id="email" name="email" placeholder="Your email@example.com"required>

                <label for="lname">Address</label>
                <input type="text" id="lname" name="address" placeholder="Your address..."required>
                
                <label for="text-area">Message</label>
                <textarea name="message" id="text-area" cols="30" rows="5"  placeholder="Your message please" required></textarea>
                
                <input type="submit" name="submit" value="SEND">
            </form>
            <div class="social-icons">
                <h3>Contact us here</h3>
                <p>+250 787 740 628</p>
            </div>
            <div>
                <address>
                    Kigali City, Nyarugenge..
                </address>
            </div>
        </div>
    </div>
</main>
<footer>
    <div class="footer">
        <div class="footer-top">
            <div class="footer-about">
                <h2 class="footer-heading mb-4">About Us</h2>
                <p> OUR MISSION<br>
                    - Provide high quality products and service.<br>
                    - Respond immediately to the changing needs of our clients.<br>
                     -Achieve complete customer satisfaction.<br>
                    - Improve our service continuously.</p>
            </div>
            <div class="footer-contact">
                <h3>Contact us on Social media.</h3>
                <div class="social-icons">
                   
                    <a href="https://www.facebook.com/sciandagroup" target="_blank"><i class="fab fa-facebook-square"></i></a>
                    <a href="https://www.instagram.com/sciandagroup" target="_blank"><i class="fab fa-instagram-square"></i></a>
                    <a href="https://www.youtube.com/@SCRWANDA" target="_blank"><i class="fab fa-youtube-square"></i></a>
                    <a href="https://www.twitter.com/sciandagroup" target="_blank"><i class="fab fa-twitter-square"></i></a>
                </div>
            </div>
        </div>
        
        <p>&copy; All right Reserved by SCIANDA GROUP LTD.</p>
    </div>
</footer>
</body>
</html>
