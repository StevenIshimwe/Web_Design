<?php
$connect =mysqli_connect("localhost","root",'',"emergingtech");

if(isset($_GET['delete'])){
    $email= $_GET['delete'];

    $delete = mysqli_query($connect,"Delete from Contact where email='$email'");

    if($delete){
        echo"<script>alert('Deleted successfully!')</script>";
        include "displayMessage.php";
    }else{
    echo"<script>alert('Delete fail!')</script>";

}
}


?>