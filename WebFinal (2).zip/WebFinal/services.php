<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
        }

        .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background-color: #333;
            color: white;
            text-align: center;
            font-size: 16px;
        }
        .orange-background{
            background-color: rgba(22, 3, 167, 0.92);
        }

        .navbar {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-content: center;
            align-items: center;
            height: 50px;
            background-color: #3c3e3f;
            padding: 5px;
        }

        .navbar h2 {
            margin-left: 10px;
        }

        .nav-links {
            display: flex;
            align-items: center;
        }

        .nav-links a {
            text-decoration: none;
            padding: 15px;
            color: white;
        }

        .hover > a:hover {
            color: black;
            background-color: aquamarine;
            border-radius: 30px;
            transition: width 2s;
        }

        .footer {
            background-color: #3c3e3f;
            display: flex;
            flex-direction: column;
            align-items: center;
            color: white; 
            padding: 20px;
        }

        .footer-top {
            width: 100%;
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .footer-middle {
            width: 100%;
            text-align: center;
            margin-bottom: 10px;
        }

        .footer-about, .footer-contact {
            width: 40%;
        }

        
        .social-icons {
            margin-top: 20px;
        }

        .social-icons a {
            display: inline-block;
            margin: 0 10px;
            color: white;
            font-size: 1.5rem;
        }

        .social-icons a:hover {
            color: #3b5998; 
        }

        .footer a {
            margin-left: 10px;
        }

        .footer-subscribe .form-control {
            border-color: #fff !important;
        }

        .footer-subscribe .form-control::placeholder {
            color: rgba(255, 255, 255, 0.5);
            font-weight: 200;
            font-style: italic;
        }

        .footer-subscribe .btn {
            height: 43px;
            line-height: 1;
            border: 1px solid #fff;
            background: #fff !important;
            color: #000 !important;
        }

        .footer-subscribe .btn:hover, .footer-subscribe .btn:focus, .footer-subscribe .btn:active {
            border: 1px solid #fff;
        }

        .additional-section {
            background-color: white;
            text-align: center;
            padding: 40px;
            margin-top: 20px;
        }
        .footer-contact {
            display: flex;
            align-items:end;
            flex-direction: column;

        
        }

        .site-section {
            padding: 2.5em 0; }
            @media (min-width: 768px) {
              .site-section {
                padding: 8em 0; } }
            .site-section.site-section-sm {
              padding: 4em 0; }
          
          .site-section-heading {
            padding-bottom: 20px;
            margin-bottom: 0px;
            position: relative;
            font-size: 2.5rem; }
            @media (min-width: 768px) {
              .site-section-heading {
                font-size: 3rem; } }
          
          .site-footer {
            padding: 4em 0;
            background: #343a40; }
            @media (min-width: 768px) {
              .site-footer {
                padding: 8em 0; } }
            .site-footer .border-top {
              border-top: 1px solid rgba(255, 255, 255, 0.1) !important; }
            .site-footer p {
              color: rgba(255, 255, 255, 0.7); }
            .site-footer h2, .site-footer h3, .site-footer h4, .site-footer h5 {
              color: #fff; }
            .site-footer a {
              color: rgba(255, 255, 255, 0.7);
              text-decoration: underline; }
              .site-footer a:hover {
                color: white; }
            .site-footer ul li {
              margin-bottom: 10px; }
            .site-footer .footer-heading {
              font-size: 16px;
              color: #fff; }
          

        
        .additional-section h1 {
            font-size: 2.5rem;
            color: #333;
        }
        

        .service-image {
            width: 50px;
            margin-bottom: 20px;
        }

        .unit-4 {
            display: flex;
            align-items: center;
            flex-direction: column;
        }

        .unit-4-icon img {
            width: 100%;
            max-width: 50px;
        }
        .row{
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            gap: 30px;
        }
        .row .mb-4{
            width: 30%;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="navbar">
            <div>
                <h2><img src="download.jpg" width="100" height="50" ></h2>
            </div>
            <div class="nav-links hover">
                <a href="./home.php">Home</a>
                <a href="./car.php">Cars</a>
                <a href="./house.php">Houses</a>
                <a href="./about.php">About Us</a>
                <a href="./services.php">Services</a>
                <a href="./contact.php">Contact Us</a>
            </div>
        </div>
    </header>
    <br><br><br><br><br>
    <section class="site-section border-bottom bg-light" id="services-section">
        <div class="container">
            <div class="row mb-5">
                <div class="col-12 text-center" data-aos="fade">
                    <u><h2 class="section-title mb-3">Our Services</h2></u>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 mb-4" data-aos="fade-up">
                    <div class="unit-4">
                        <div class="unit-4-icon">
                            <img src="img-electronicdevices/005-megaphone.svg" alt="Business Consulting" class="service-image">
                        </div>
                        <div>
                            <h3>VEHICLE SALES (All Makes)</h3>
                            <p>We are the best in car saling.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 mb-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="unit-4">
                        <div class="unit-4-icon">
                            <img src="img-electronicdevices/001-wallet.svg" alt="Credit Card" class="service-image">
                        </div>
                        <div>
                            <h3>SALE OF HOUSES</h3>
                            <p>We sale houses in Rwanda.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 mb-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="unit-4">
                        <div class="unit-4-icon">
                            <img src="img-electronicdevices/002-rich.svg" alt="Income Monitoring" class="service-image">
                        </div>
                        <div>
                            <h3>CAR RENTAL</h3>
                            <p> We provide cars in a short time</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 mb-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="unit-4">
                        <div class="unit-4-icon">
                            <img src="img-electronicdevices/003-notes.svg" alt="Financial Investment" class="service-image">
                        </div>
                        <div>
                            <h3>E-COMMERCE</h3>
                            <p>We have an e-commerce platform that will help you to Buy, Sell or Advertise products and services online.
                                For more details, Visit sciandamarket.com</p>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    <footer>
        <div class="footer">
            <div class="footer-top">
                <div class="footer-about">
                    <h2 class="footer-heading mb-4">About Us</h2>
                    <p> OUR MISSION<br>
                        - Provide high quality products and service.<br>
                        - Respond immediately to the changing needs of our clients.<br>
                         -Achieve complete customer satisfaction.<br>
                        - Improve our service continuously.</p>
                </div>
                <div class="footer-contact">
                    <h3>Contact us on Social media.</h3>
                    <div class="social-icons">
                       
                        <a href="https://www.facebook.com/sciandagroup" target="_blank"><i class="fab fa-facebook-square"></i></a>
                        <a href="https://www.instagram.com/sciandagroup" target="_blank"><i class="fab fa-instagram-square"></i></a>
                        <a href="https://www.youtube.com/@SCRWANDA" target="_blank"><i class="fab fa-youtube-square"></i></a>
                        <a href="https://www.twitter.com/sciandagroup" target="_blank"><i class="fab fa-twitter-square"></i></a>
                    </div>
                </div>
            </div>
            
            <p>&copy; All right Reserved by SCIANDA GROUP LTD.</p>
        </div>
    </footer>
</body>
</html>
